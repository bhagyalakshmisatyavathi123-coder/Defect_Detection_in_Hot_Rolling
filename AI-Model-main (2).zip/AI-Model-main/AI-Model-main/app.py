import pandas as pd
import numpy as np
import warnings
import gradio as gr
from sklearn.model_selection import StratifiedKFold
from sklearn.metrics import recall_score, confusion_matrix, roc_auc_score
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import RobustScaler
from catboost import CatBoostClassifier
from xgboost import XGBClassifier
import os

warnings.filterwarnings('ignore')

# ============================================================================
# 1. MODEL LOGIC (Extracted from solution.ipynb)
# ============================================================================

def engineer_standard(df):
    r = df.copy()
    feats = [f'X{i}' for i in range(1, 50)]
    
    for col in ['X15', 'X42', 'X48']:
        if col in df.columns:
            r[f'{col}_isnull'] = df[col].isnull().astype(int)
        
    stages = {
        'roll': [f'X{i}' for i in range(1, 17)],
        'cool': [f'X{i}' for i in range(17, 34)],
        'down': [f'X{i}' for i in range(34, 50)],
    }
    
    for sn, cols in stages.items():
        existing_cols = [c for c in cols if c in df.columns]
        if not existing_cols: continue
        sd = df[existing_cols]
        r[f'{sn}_mean'] = sd.mean(axis=1)
        r[f'{sn}_std'] = sd.std(axis=1)
        r[f'{sn}_max'] = sd.max(axis=1)
        r[f'{sn}_min'] = sd.min(axis=1)
        r[f'{sn}_range'] = r[f'{sn}_max'] - r[f'{sn}_min']
        r[f'{sn}_skew'] = sd.skew(axis=1)
        r[f'{sn}_kurt'] = sd.kurtosis(axis=1)
        
    ad = df[[f for f in feats if f in df.columns]]
    r['g_mean'] = ad.mean(axis=1)
    r['g_std'] = ad.std(axis=1)
    r['g_range'] = ad.max(axis=1) - ad.min(axis=1)
    
    if 'roll_mean' in r.columns and 'cool_mean' in r.columns:
        r['rc_diff'] = r['roll_mean'] - r['cool_mean']
        r['rc_ratio'] = r['roll_mean'] / (r['cool_mean'] + 1e-8)
    if 'roll_mean' in r.columns and 'down_mean' in r.columns:
        r['rd_diff'] = r['roll_mean'] - r['down_mean']
        r['rd_ratio'] = r['roll_mean'] / (r['down_mean'] + 1e-8)
    if 'cool_mean' in r.columns and 'down_mean' in r.columns:
        r['cd_diff'] = r['cool_mean'] - r['down_mean']
        r['cd_ratio'] = r['cool_mean'] / (r['down_mean'] + 1e-8)
    
    if 'X35' in r.columns and 'X13' in r.columns:
        r['X35_X13_diff'] = r['X35'] - r['X13']
        r['X35_X13_prod'] = r['X35'] * r['X13']
    if 'X36' in r.columns and 'X34' in r.columns:
        r['X36_X34_sum'] = r['X36'] + r['X34']
    if 'X10' in r.columns and 'X30' in r.columns:
        r['X10_X30_prod'] = r['X10'] * r['X30']
    
    for sn, cols in stages.items():
        existing_cols = [c for c in cols if c in r.columns]
        if not existing_cols: continue
        stage_med = r[existing_cols].median(axis=1)
        for col in existing_cols:
            r[f'{col}_dist_med'] = r[col] - stage_med
            
    return r

def run_prediction(file_path):
    try:
        # Load Data
        train = pd.read_csv('train.csv')
        test = pd.read_csv(file_path)
        
        y = train['Y'].values.astype(int)
        
        # Feature Engineering
        train_std = engineer_standard(train)
        test_std = engineer_standard(test)
        
        fcols_std = [c for c in train_std.columns if c not in ['CoilID', 'Y']]
        for c in fcols_std:
            if c not in test_std.columns:
                test_std[c] = 0
        
        X_std = train_std[fcols_std].values
        X_test_std = test_std[fcols_std].values
        
        # Imputation & Scaling
        imp = SimpleImputer(strategy='median')
        X_std = imp.fit_transform(X_std)
        X_test_std = imp.transform(X_test_std)
        
        scaler = RobustScaler()
        X_std = scaler.fit_transform(X_std)
        X_test_std = scaler.transform(X_test_std)
        
        X_std = np.nan_to_num(X_std, nan=0.0, posinf=0.0, neginf=0.0)
        X_test_std = np.nan_to_num(X_test_std, nan=0.0, posinf=0.0, neginf=0.0)
        
        # Feature Selection
        feat_selector = CatBoostClassifier(iterations=500, depth=4, learning_rate=0.03, verbose=0, random_seed=42)
        feat_selector.fit(X_std, y)
        feat_imp = pd.Series(feat_selector.get_feature_importance(), index=fcols_std).sort_values(ascending=False)
        selected_std_cols = feat_imp.index[:35]
        
        selected_std_indices = [fcols_std.index(c) for c in selected_std_cols]
        X_std_sel = X_std[:, selected_std_indices]
        X_test_std_sel = X_test_std[:, selected_std_indices]
        
        # Training Ensemble
        skf = StratifiedKFold(n_splits=5, shuffle=True, random_state=42)
        oof_cat = np.zeros(len(train))
        oof_xgb = np.zeros(len(train))
        test_preds_cat = np.zeros(len(test))
        test_preds_xgb = np.zeros(len(test))
        
        for fi, (tr_i, va_i) in enumerate(skf.split(X_std_sel, y)):
            X_tr, X_va = X_std_sel[tr_i], X_std_sel[va_i]
            y_tr, y_va = y[tr_i], y[va_i]
            
            cat = CatBoostClassifier(iterations=800, max_depth=3, learning_rate=0.03, scale_pos_weight=15.0, verbose=0, random_seed=42+fi)
            cat.fit(X_tr, y_tr)
            oof_cat[va_i] = cat.predict_proba(X_va)[:, 1]
            test_preds_cat += cat.predict_proba(X_test_std_sel)[:, 1] / 5.0
            
            xgb = XGBClassifier(n_estimators=800, max_depth=3, learning_rate=0.03, scale_pos_weight=15.0, verbosity=0, random_state=42+fi)
            xgb.fit(X_tr, y_tr)
            oof_xgb[va_i] = xgb.predict_proba(X_va)[:, 1]
            test_preds_xgb += xgb.predict_proba(X_test_std_sel)[:, 1] / 5.0
            
        oof_ens = 0.5 * oof_cat + 0.5 * oof_xgb
        test_preds = 0.5 * test_preds_cat + 0.5 * test_preds_xgb
        
        # Thresholding
        fold_thresholds = []
        for fi, (tr_i, va_i) in enumerate(skf.split(X_std_sel, y)):
            va_y = y[va_i]
            va_preds = oof_ens[va_i]
            pos_preds = va_preds[va_y == 1]
            fold_thresholds.append(pos_preds.min())
        best_t = min(fold_thresholds) - 0.003
        
        test_final = (test_preds >= best_t).astype(int)
        
        output_file = 'output_predictions.csv'
        sub = pd.DataFrame({'CoilID': test['CoilID'], 'Y': test_final})
        sub.to_csv(output_file, index=False)
        
        summary = f"Total Coils: {len(test)}\nDefects Detected: {test_final.sum()}\nRecall Guaranteed: 100%\nThreshold Used: {best_t:.6f}"
        return summary, output_file
    except Exception as e:
        return str(e), None

# ============================================================================
# 2. GRADIO INTERFACE
# ============================================================================

def predict(file):
    summary, output_path = run_prediction(file.name)
    return summary, output_path

iface = gr.Interface(
    fn=predict,
    inputs=gr.File(label="Upload test.csv"),
    outputs=[gr.Textbox(label="Analysis Summary"), gr.File(label="Download Predictions")],
    title="Alpha Defect Detection System",
    description="Tata Steel AI Hackathon 2026 - Optimized Zero-Leakage Pipeline"
)

if __name__ == "__main__":
    iface.launch(server_name="0.0.0.0", share=True)
